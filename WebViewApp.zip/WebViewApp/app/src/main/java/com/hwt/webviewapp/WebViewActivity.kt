package com.hwt.webviewapp


import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import android.webkit.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*
import android.content.pm.PackageInfo
import android.provider.MediaStore
import androidx.webkit.WebViewCompat

class WebViewActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var mFilePathCallback: ValueCallback<Array<Uri>>? = null
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_web_view)

        val webViewPackage = WebViewCompat.getCurrentWebViewPackage(this)?.versionName
        Log.d("WebView Version", "WebView Version: $webViewPackage")

        webView = findViewById(R.id.webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.setGeolocationEnabled(true)
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                MY_PERMISSIONS_REQUEST_LOCATION
            )
        }

        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
            ),
            REQUEST_PERMISSION_CODE
        )

        webView.webViewClient = object : WebViewClient(){



            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)


                view?.evaluateJavascript("setTimeout(function(){document.getElementById('btnApertura').click();},100)") {

                }
            }

        }

        webView.clearCache(true)

        webView.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun onButtonClick() {
                onBackPressed()
            }
        }, "Android")

        val htmlContent = """
            <!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Chat</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <style>

          .rotar{
            animation: rotar 2s infinite linear;
          }
          @keyframes rotar {
            from {
              transform: rotate(0deg);
            }
            to{
              transform: rotate(360deg);
            }
          }
        </style>
	</head>
   <!-- <body style="background-color: rgb(0, 122, 254); " >-->
      <body style="background-color: transparent; " ></body>
		<!--<button id="btnApertura" style="background-color: transparent; border-color: transparent;"></button>-->
		
 <script type='text/javascript'>
  (function() {
    var proto  = document.location.protocol || 'http:';
    var node   = document.createElement('script');
    node.type  = 'text/javascript';
    node.async = true;
    node.src   = 'https://webchat-farmacorp.i6.inconcertcc.com/v3/click_to_chat?token=A52FE349C14B5223115674B426C1B80A';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(node, s);
  })();
</script>


<div id="cont_img" style="position: absolute; display: flex; align-items: center; justify-content: center; height: 100%; width: 100%; top:0; left:0;">
  <div style="position: relative;">
    <button id="btnApertura" style="background-color: transparent; border-color: transparent;">
    <img id = "img" class="rotar" src="https://chat1-farmacorp.i6.inconcertcc.com/inconcert/apps/webdesigner/designer/applications/A52FE349C14B5223115674B426C1B80A/AppWebChat/resources/profilechat.svg" style="height: auto;">
  </button>
  <button id="btnCambioActividad" style="background-color: transparent; border-color: transparent;">
    
  </button>
  </div>

</div>

<!--<script>
  setTimeout(function(){
    var btnAp = document.getElementById("btnApertura")
      btnAp.click()
  },1200)

</script>-->

<script>
  setTimeout(function(){
    var contenedor = document.getElementById("cont_img")
    var img = document.getElementById("img")
    //img.classList.remove("rotar")
   //contenedor.style.display = "none"
  },12000)

</script>


<script>
    var eventos = [];

document.addEventListener("DOMContentLoaded", function(){

    document.querySelector("#btnCambioActividad").addEventListener("click", function(){
		window.Android.onButtonClick();
      });
	
});

  function recibirMensaje(event){
    //console.log("LOG: ",event.origin)
      if(event.origin != "https://chat1-farmacorp.i6.inconcertcc.com"){
        //console.log("LOG: ","Entro")
        return;
      }

      
      eventos.push(event.data[1])
      console.log("LOG: arreglo - ",eventos)
      if(eventos[eventos.length-1] =="HIDE_CHAT_RESPONSE" && eventos[eventos.length-3] != "SET_ARGS"){
        //document.querySelector("#btnCambioActividad").innerText = "Chao"
        document.querySelector("#btnCambioActividad").click()
      }
  }

  window.addEventListener("message", recibirMensaje, false);

</script>
    </body>
</html>
        """
        //webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, true, false)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                Log.d("WebViewActivity", "onShowFileChooser() llamado")

                mFilePathCallback = filePathCallback

                // Crear un Intent para abrir el selector de archivos de la cámara
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

                // Crear un Intent para abrir el selector de archivos
                val fileIntent = Intent(Intent.ACTION_GET_CONTENT)
                fileIntent.type = "*/*" // Tipo de archivo, "*/*" permite seleccionar cualquier tipo de archivo

                // Crear un Intent para envolver ambos Intents
                val chooserIntent = Intent.createChooser(fileIntent, "Selecciona un archivo")
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cameraIntent))

                // Verificar si hay actividades que puedan manejar el Intent
                if (chooserIntent.resolveActivity(packageManager) != null) {
                    startActivityForResult(chooserIntent, FILE_CHOOSER_REQUEST_CODE)
                } else {
                    // Manejar el caso en que no haya ninguna aplicación disponible para manejar el Intent
                    Log.e("WebViewActivity", "No hay aplicaciones disponibles para manejar el Intent.")
                }

                return true
            }
        }
        checkAndRequestPermissions()
        webView.loadUrl("https://webrtc.inconcertcc.com/test_juan/farmacorp/webchat/")
        //webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)


    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)


        if (hasFocus) {

            webView.evaluateJavascript("setTimeout(function(){document.getElementById('btnApertura').click();},100)") {
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                // Seleccionar el archivo y devolverlo al callback
                val result = if (data == null || resultCode != Activity.RESULT_OK) null else data.data
                mFilePathCallback?.onReceiveValue(arrayOf(result ?: Uri.EMPTY))
                mFilePathCallback = null
            } else {
                // En caso de que la selección de archivos se haya cancelado, devolver null al callback
                mFilePathCallback?.onReceiveValue(null)
                mFilePathCallback = null
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION_CODE) {
            var allPermissionsGranted = true
            for (result in grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false
                    break
                }
            }

            if (allPermissionsGranted) {
                Log.d("Permission", "Todos los permisos otorgados.")

            } else {
                Log.d("Permission", "Al menos un permiso no otorgado.")

            }
        }
    }

    companion object {
        private const val MY_PERMISSIONS_REQUEST_LOCATION = 1001
        private const val REQUEST_PERMISSION_CODE = 123
        private const val FILE_CHOOSER_REQUEST_CODE = 124
        private const val REQUEST_STORAGE_PERMISSION = 1001
    }

    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )

        ActivityCompat.requestPermissions(this, permissions, REQUEST_PERMISSION_CODE)
        Log.d("Permission", "Solicitando permisos...")
    }
}