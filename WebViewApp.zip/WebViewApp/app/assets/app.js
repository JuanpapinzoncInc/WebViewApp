var eventos = [];

document.addEventListener("DOMContentLoaded", function(){

    document.querySelector("#btnCambioActividad").addEventListener("click", function(){
        //alert("disparó")
		window.Android.onButtonClick();
      });
	
});

  function recibirMensaje(event){
    //console.log("LOG: ",event.origin)
      if(event.origin != "https://chat1-farmacorp.i6.inconcertcc.com"){
        //console.log("LOG: ","Entro")
        return;
      }

      
      eventos.push(event.data[1])
      console.log("LOG: arreglo - ",eventos)
      if(eventos[eventos.length-1] =="HIDE_CHAT_RESPONSE" && eventos[eventos.length-3] != "SET_ARGS"){
        //document.querySelector("#btnCambioActividad").innerText = "Chao"
        document.querySelector("#btnCambioActividad").click()
      }
  }

  window.addEventListener("message", recibirMensaje, false);



 
